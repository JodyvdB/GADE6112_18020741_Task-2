﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    class GameEngine
    {

        public Map myMap = new Map();
        private frmRTSMain form;
        private GroupBox messageGroup;

        // Constructor with the form and the groupbox as parameters.
        public GameEngine(frmRTSMain form, GroupBox messageGroup)
        {
            this.form = form;
            this.messageGroup = messageGroup;

            // A 'foreach' is a for loop that essentially runs until the parameter's count size is reached.
            foreach(Unit u in myMap.units)
            {
                // Buttons are how the units are represented on the game board.
                // Locations are randomized and sizes are all the same. 
                // The symbol variable is used as the button text to allow for identification of units.
                Button b = new Button();
                b.Location = new Point(u.XPos * 15, u.YPos * 15);
                b.Size = new Size(30, 30);
                b.Text = u.Symbol;

                // Test to determine the team and therefore the colour the unit will have as the background of the button.
                if (u.Team == 0)
                {
                    b.BackColor = Color.Red;

                } else
                {
                    b.BackColor = Color.Blue;
                }

                // Test to determine which type of unit it is. This sets the colour of the text on the button.
                if (u.GetType() == typeof(MeleeUnit))
                {
                    b.ForeColor = Color.White;

                } else if (u.GetType() == typeof(RangedUnit))
                {
                    b.ForeColor = Color.Black;
                }

                // Whenever a unit's button is clicked, its information is added to the list box.
                b.Click += buttonClick;
                this.form.Controls.Add(b);
            }

            foreach (ResourceBuilding rB in myMap.rBuildings)
            {
                // Buttons are how the buildings are represented on the game board.
                // Locations are randomized and sizes are all the same. 
                // The symbol variable is used as the button text to allow for identification of units.
                Button u = new Button();
                u.Location = new Point(rB.X * 15, rB.Y * 15);
                u.Size = new Size(30, 30);
                u.Text = ("" + rB.Symbol);

                // Test to determine the team and therefore the colour the unit will have as the background of the button.
                if (rB.Team == 0)
                {
                    u.BackColor = Color.Pink;
                }
                else
                {
                    u.BackColor = Color.Turquoise;
                }

                u.ForeColor = Color.Orange;

                // Whenever a unit's button is clicked, its information is added to the list box.
                u.Click += buttonClick;
                this.form.Controls.Add(u);
            }

            foreach (FactoryBuilding fB in myMap.fBuildings)
            {
                // Buttons are how the buildings are represented on the game board.
                // Locations are randomized and sizes are all the same. 
                // The symbol variable is used as the button text to allow for identification of units.
                Button u = new Button();
                u.Location = new Point(fB.X * 15, fB.Y * 15);
                u.Size = new Size(30, 30);
                u.Text = ("" + fB.Symbol);

                // Test to determine the team and therefore the colour the unit will have as the background of the button.
                if (fB.Team == 0)
                {
                    u.BackColor = Color.Pink;

                }
                else
                {
                    u.BackColor = Color.Turquoise;
                }

                u.ForeColor = Color.LimeGreen;

                // Whenever a unit's button is clicked, its information is added to the list box.
                u.Click += buttonClick;
                this.form.Controls.Add(u);
            }
        }

        public void updateDisplay()
        {
            // Resets the entire game board outside of the group box. This allows for the units to move and update their positions.
            form.Controls.Clear();
            form.Controls.Add(messageGroup);

            // Loop that updates every postion for every unit on the game board at that moment.
            foreach (Unit u in myMap.units)
            {
                // A new button has to be created in the new location of the unit. 
                // The rest of this method is a repeat to allow for information to work and be displayed throughout the simulation.
                Button b = new Button();
                b.Location = new Point(u.XPos * 15, u.YPos * 15);
                b.Size = new Size(30, 30);
                b.Text = u.Symbol;

                if (u.Team == 0)
                {
                    b.BackColor = Color.Red;

                } else
                {
                    b.BackColor = Color.Blue;
                }

                if (u.GetType() == typeof(MeleeUnit))
                {
                    b.ForeColor = Color.White;

                }
                else
                {
                    b.ForeColor = Color.Black;
                }

                b.Click += buttonClick;
                form.Controls.Add(b);
            }

            foreach (ResourceBuilding rB in myMap.rBuildings)
            {
                // Locations are randomized and sizes are all the same. 
                // The symbol variable is used as the button text to allow for identification of units.
                Button u = new Button();
                u.Location = new Point(rB.X * 15, rB.Y * 15);
                u.Size = new Size(30, 30);
                u.Text = ("" + rB.Symbol);

                // Test to determine the team and therefore the colour the unit will have as the background of the button.
                if (rB.Team == 0)
                {
                    u.BackColor = Color.Pink;
                }
                else
                {
                    u.BackColor = Color.Turquoise;
                }

                u.ForeColor = Color.Orange;

                // Whenever a unit's button is clicked, its information is added to the list box.
                u.Click += buttonClick;
                this.form.Controls.Add(u);
            }

            foreach (FactoryBuilding fB in myMap.fBuildings)
            {
                // Locations are randomized and sizes are all the same. 
                // The symbol variable is used as the button text to allow for identification of units.
                Button u = new Button();
                u.Location = new Point(fB.X * 15, fB.Y * 15);
                u.Size = new Size(30, 30);
                u.Text = ("" + fB.Symbol);

                // Test to determine the team and therefore the colour the unit will have as the background of the button.
                if (fB.Team == 0)
                {
                    u.BackColor = Color.Pink;

                }
                else
                {
                    u.BackColor = Color.Turquoise;
                }

                u.ForeColor = Color.LimeGreen;

                // Whenever a unit's button is clicked, its information is added to the list box.
                u.Click += buttonClick;
                this.form.Controls.Add(u);
            }
        }

        public void updateMap()
        {
            // Foreach loop for every alive unit.
            foreach (Unit u in myMap.units)
            {
                // Determining the closest unit to the current unit.
                Unit closestUnit = u.closestUnit(ref myMap.units);


                // Test to determine if the unit is ranged or melee. 
                // This is so that the correct 'DeathException' can be called.
                // The reason the integer 30 is used is because one button representing a unit has a size of 30 by 30. 
                // So the distance to a unit right next to it would be 30.
                if (u.AttackRange == 30)
                {
                    // If possible, the current unit will move.
                    try
                    {
                        u.move(ref closestUnit);

                    }

                    // Else the unit is dead and needs to be removed from the array of units.
                    catch (MeleeUnit.DeathException d)
                    {
                        // The listbox prints the message that the unit is dead.
                        form.displayInfo(d.Message);
                        Unit[] tmpArr = new Unit[myMap.units.Count() - 1];

                        int count = 0;

                        // Loop that runs for the amount of alive units. 
                        // The implementation of the loop allows for the array to be rebuilt without the current unit that is now dead.
                        for (int loop = 0; loop < myMap.units.Count(); loop++)
                        {
                            if (u != myMap.units[loop])
                            {
                                tmpArr[count++] = myMap.units[loop];
                            }
                        }

                        // The myMap array is then updated to represent the changes.
                        myMap.units = tmpArr;
                    }
                
                // If the unit is ranged, the code is all the same as a melee unit except for that DeathException call.
                } else
                {
                    try
                    {
                        u.move(ref closestUnit);

                    }
                    catch (RangedUnit.DeathException d)
                    {
                        form.displayInfo(d.Message);
                        Unit[] tmpArr = new Unit[myMap.units.Count() - 1];

                        int count = 0;

                        for (int loop = 0; loop < myMap.units.Count(); loop++)
                        {
                            if (u != myMap.units[loop])
                            {
                                tmpArr[count++] = myMap.units[loop];
                            }
                        }

                        myMap.units = tmpArr;
                    }
                }
            }

            foreach (FactoryBuilding fB in myMap.fBuildings)
            {
                try
                {
                    fB.generateUnit();
             
                }
                catch (FactoryBuilding.DeathException d)
                {
                    form.displayInfo(d.Message);
                    FactoryBuilding[] tmpArr = new FactoryBuilding[myMap.fBuildings.Count() - 1];

                    int count = 0;

                    for (int loop = 0; loop < myMap.fBuildings.Count(); loop++)
                    {
                        if (fB != myMap.fBuildings[loop])
                        {
                            tmpArr[count++] = myMap.fBuildings[loop];
                        }
                        }

                        myMap.fBuildings = tmpArr;
                    }
            }

            foreach (ResourceBuilding rB in myMap.rBuildings)
            {
                try
                {
                    rB.generateResource();

                }
                catch (ResourceBuilding.DeathException d)
                {
                    form.displayInfo(d.Message);
                    ResourceBuilding[] tmpArr = new ResourceBuilding[myMap.rBuildings.Count() - 1];

                    int count = 0;

                    for (int loop = 0; loop < myMap.rBuildings.Count(); loop++)
                    {
                        if (rB != myMap.rBuildings[loop])
                        {
                            tmpArr[count++] = myMap.rBuildings[loop];
                        }
                    }

                    myMap.rBuildings = tmpArr;
                }
            }
        }

        // Method for whenever a unit's button is clicked.
        public void buttonClick(object sender, EventArgs args)
        {
            // foreach loop that adds the toString of information of the clicked unit to the listbox.
            foreach(Unit u in myMap.units)
            {
                // Test to see if the text on the button(the 'sender') is the same as the unit in the unit array at the position of the loop.
                if (((Button)sender).Text == u.Symbol)
                {
                    form.displayInfo(u.toString());
                    break;
                }
            }

            foreach (FactoryBuilding fB in myMap.fBuildings)
            {
                // Test to see if the text on the button(the 'sender') is the same as the unit in the unit array at the position of the loop.
                if (((Button)sender).Text == ("" + fB.Symbol))
                {
                    form.displayInfo(fB.toString());
                    break;
                }
            }

            foreach (ResourceBuilding rB in myMap.rBuildings)
            {
                // Test to see if the text on the button(the 'sender') is the same as the unit in the unit array at the position of the loop.
                if (((Button)sender).Text == ("" + rB.Symbol))
                {
                    form.displayInfo(rB.toString());
                    break;
                }
            }
        }
    }
}
