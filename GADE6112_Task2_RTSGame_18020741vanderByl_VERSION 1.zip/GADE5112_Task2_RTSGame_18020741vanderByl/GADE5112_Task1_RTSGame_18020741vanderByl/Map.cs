﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    class Map
    {
        public Unit[] units;
        public ResourceBuilding[] rBuildings;
        public FactoryBuilding[] fBuildings;
        int fCount = 0;
        int rCount = 0;
        // Using the Random class, we can randomize different characteristics of the different units.
        Random r = new Random();

        // constructor
        public Map()
        {
            // BUILDING GENERATION
            for (int loop = 0; loop < 8; loop++)
            {
                int newX = r.Next(0, 20);
                int newY = r.Next(0, 20);

                // '%' or 'mod' is used as a way to calculate the remainder of a division calculation.
                int team = loop % 2;

                // Depending which team value was randomized, a bulding will be created in that team, it will then be randomized what kind of building is made.
                switch (r.Next(0, 2))
                {
                    case 0:
                        int typeOfFactory = r.Next(0, 2);
                        fBuildings[fCount] = new FactoryBuilding(newX, newY, 150, team, typeOfFactory, 2);
                        fCount++;
                        break;

                    case 1:
                        int typeOfResource = r.Next(0, 2);
                        rBuildings[rCount] = new ResourceBuilding(newX, newY, 150, team, 0, 50, typeOfResource);
                        rCount++;
                        break;

                    default:
                        break;
                }
            }

            // UNIT GENERATION
            // Running a for loop for as many units there are in the array.
            for (int loop = 0; loop < 10; loop++)
            {
                int newX = r.Next(0, 20);
                int newY = r.Next(0, 20);

                // '%' or 'mod' is used as a way to calculate the remainder of a division calculation.
                int team = loop % 2;

                int tempAttack = 0;

                // Here we are randomizing the units' potential attack damage values.
                switch (r.Next(0, 4))
                {
                    case 0: tempAttack = 40;  break;
                    case 1: tempAttack = 50;  break;
                    case 2: tempAttack = 60;  break;
                    case 3: tempAttack = 90;  break;
                }

                // Depending which team value was randomized, a unit will be created using the Melee or Ranged units classes/objects in the team that was randomized.
                switch (r.Next(0, 2))
                {
                    case 0: units[loop] = new MeleeUnit(newX, newY, 100, 2, tempAttack, 30, team, loop.ToString()); break;
                    case 1: units[loop] = new RangedUnit(newX, newY, 100, 1, tempAttack, 90, team, loop.ToString()); break;
                }
            }
        }

        // method for reading the info of all units and buildings from their specific text files.
        public void read(string docPath)
        {
            string line;
            int countUnits = 0;
            int countFBuildings = 0;
            int countRBuildings = 0;

            // Ranged Units
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("C:\\Ranged Units.txt");

                //Read the first line of text
                line = sr.ReadLine();
                int[] stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                units[countUnits] = new RangedUnit(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6], countUnits.ToString());
                countUnits++;


                //Continue to read until you reach end of file
                while (line != null)
                {
                    //Read the next line
                    line = sr.ReadLine();
                    stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                    units[countUnits] = new RangedUnit(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6], countUnits.ToString());
                    countUnits++;
                }

                //close the file
                sr.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }

            // Melee Units
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("C:\\Melee Units.txt");

                //Read the first line of text
                line = sr.ReadLine();
                int[] stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                units[countUnits] = new MeleeUnit(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6], countUnits.ToString());
                countUnits++;


                //Continue to read until you reach end of file
                while (line != null)
                {
                    //Read the next line
                    line = sr.ReadLine();
                    stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                    units[countUnits] = new MeleeUnit(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6], countUnits.ToString());
                    countUnits++;
                }

                //close the file
                sr.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }

            // Factory Buildings
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("C:\\Factory Buildings.txt");

                //Read the first line of text
                line = sr.ReadLine();
                int[] stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                fBuildings[countFBuildings] = new FactoryBuilding(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5]);
                countFBuildings++;


                //Continue to read until you reach end of file
                while (line != null)
                {
                    //Read the next line
                    line = sr.ReadLine();
                    stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                    fBuildings[countFBuildings] = new FactoryBuilding(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5]);
                    countFBuildings++;
                }

                //close the file
                sr.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }

            // Resource Buildings
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("C:\\Resource Buildings.txt");

                //Read the first line of text
                line = sr.ReadLine();
                int[] stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                rBuildings[countRBuildings] = new ResourceBuilding(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6]);
                countRBuildings++;


                //Continue to read until you reach end of file
                while (line != null)
                {
                    //Read the next line
                    line = sr.ReadLine();
                    stats = line.Split(',').Select(p => int.Parse(p)).ToArray();
                    rBuildings[countRBuildings] = new ResourceBuilding(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6]);
                    countRBuildings++;
                }

                //close the file
                sr.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
        }
    }
}
