﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    class RangedUnit : Unit
    {
        // Accessors and Mutators for all variables. These methods allow the variables to be accessed without having access to the variables themselves.
        public override int XPos
        {
            get
            {
                return xPos;
            }
            set
            {
                xPos = value;
            }
        }

        public override int YPos
        {
            get
            {
                return yPos;
            }
            set
            {
                yPos = value;
            }
        }

        public override int MaxHealth
        {
            get
            {
                return maxHealth;
            }
            set
            {
                maxHealth = value;
            }
        }

        public override int Health
        {
            get
            {
                return health;
            }
            set
            {
                health = value;
            }
        }

        public override int Speed
        {
            get
            {
                return speed;
            }
            set
            {
                speed = value;
            }
        }

        public override int Attack
        {
            get
            {
                return attack;
            }
            set
            {
                attack = value;
            }
        }

        public override int AttackRange
        {
            get
            {
                return attackRange;
            }
            set
            {
                attackRange = value;
            }
        }

        public override int Team
        {
            get
            {
                return team;
            }
            set
            {
                team = value;
            }
        }

        public override string Symbol
        {
            get
            {
                return symbol;
            }
            set
            {
                symbol = value;
            }
        }

        // Constructor Class to instantiate variables in the inherited Unit class.
        public RangedUnit(int xPos, int yPos, int maxHealth, int speed, int attack, int attackRange, int team, string symbol)
        {
            // "this." forces the code to use the variable located in /this/the same class.
            this.XPos = xPos;
            this.YPos = yPos;
            this.MaxHealth = maxHealth;
            this.health = this.MaxHealth;
            this.Speed = speed;
            this.Attack = attack;
            this.AttackRange = attackRange;
            this.Team = team;
            this.Symbol = symbol;
        }

        // "override" takes anything that is abstract and overrides the method and its code in the current context to give new values to it.
        public override void move(ref Unit closestUnit)
        {
            // Test to make sure that the closest unit to the current melee unit, is not the melee unit itself.
            // Therefore it is a test to see if it is the last remaining unit.
            if (this == closestUnit)
            {
                return;
            }

            // Test to see if the closest unit is not on the same team.
            if (closestUnit.Team != Team)
            {
                // Run away if health is below 25%
                if (Health < 25)
                {
                    // Random is a class that is being inherited, giving access to all the methods that correspond with the Random class.
                    // For example the Random.Next method that generates a random value in between 2 integers (max and min).
                    Random r = new Random();

                    // Speed is the move distance and we are randomising which direction the unit will run away into.
                    switch (r.Next(0, 2))
                    {
                        case 0: XPos += (1 * Speed); break;
                        case 1: XPos -= (1 * Speed); break;
                    }

                    // Same process for Y value
                    switch (r.Next(0, 2))
                    {
                        case 0: YPos += (1 * Speed); break;
                        case 1: YPos -= (1 * Speed); break;
                    }


                    // Multiple tests for the boundary of the map. No unit is allowed to go passed the boundaries.
                    if (XPos <= 0)
                    {
                        XPos = 0;
                    }
                    if (YPos >= 20)
                    {
                        YPos = 20;
                    }
                    if (YPos <= 0)
                    {
                        YPos = 0;
                    }
                    if (XPos >= 20)
                    {
                        XPos = 20;
                    }

                // Combat!
                //Math.Abs returns the absolute value of a number. 
                }
                else if (Math.Abs(XPos - closestUnit.XPos) <= Speed && Math.Abs(YPos - closestUnit.YPos) <= Speed)
                {
                    combat(ref closestUnit);

                    // Move towards closest unit.
                    // Unit may have to go backwards depending on the position of the enemy unit.
                }
                else
                {
                    if (XPos > closestUnit.XPos)
                    {
                        XPos -= Speed;
                    }
                    else if (XPos < closestUnit.XPos)
                    {
                        XPos += Speed;
                    }

                    if (YPos > closestUnit.YPos)
                    {
                        YPos -= Speed;
                    }
                    else if (YPos < closestUnit.YPos)
                    {
                        YPos += Speed;
                    }
                }
            }
        }

        public override bool isInRange(ref Unit attacker)
        {
            // Tester to see if the attacker is in the attack range of this range.
            if (DistanceTo(attacker) == attackRange)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private int DistanceTo(Unit attacker)
        {
            // The comparisons of the different x and y positions.
            int dX = Math.Abs(attacker.XPos - xPos);
            int dY = Math.Abs(attacker.YPos - yPos);

            // Converting the answer of the equation to a double. equation = squares of x and y positions added together.
            double pythagoras = Convert.ToDouble((dX * dX) + (dY * dY));

            // Getting and returning the sqaurt root of the answer of the equation due to how pythagoras works.
            return Convert.ToInt32(Math.Sqrt(pythagoras));
        }

        public override Unit closestUnit(ref Unit[] map)
        {
            Unit closest = this;
            int smallestRange = 100;
            foreach (Unit u in map)
            {
                // Test to see if the next unit in the array is part of the same team or not.
                if (u.Team != team)
                {
                    // If the distance between the 2 units are smaller than the current smallest distance, then it takes the place of the closest unit.
                    if (smallestRange > DistanceTo(u) && u != this)
                    {
                        // The smallestRange is updated.
                        smallestRange = DistanceTo(u);
                        // And the answer is updated.
                        closest = u;
                    }
                }
            }

            return closest;
        }

        // Whenever a unit attacks another, the attackers attack value will be subtracted from the victim's health.
        public override void combat(ref Unit attacker)
        {
            this.health = this.health - attacker.Attack;
            if (health <= 0)
            {
                death();
            }
        }

        // Method overriding the tostring method in order to update the info of the current unit that will be displayed 
        public override string toString()
        {
            return symbol + ": [" + xPos + ", " + yPos + "] hp: " + health + ", Attack: " + attack;
        }

        // When a unit dies, a message will be displayed.
        public override void death()
        {
            throw new DeathException(this.toString() + " IS DEAD");
        }

        // Placing this system exception in the parent class also allows both child classes to access it.
        public class DeathException : System.Exception
        {
            // A new instance of the exception class named 'DeathException' is created.
            public DeathException() : base() { }

            // Creating a base for ths class with a message in a string format.
            public DeathException(string message) : base(message) { }

            // Using the 'inner' property, we can call the original exception that caused a problem.
            public DeathException(string message, System.Exception inner) : base(message, inner) { }

            // A constructor is required for a serialization for when an excpetion proagates from a remoting server to the client.
            // Serialization is essentially the storing of objects as bytes in memory.
            // 'streaming context' = source and destination.
            protected DeathException(System.Runtime.Serialization.SerializationInfo info,
                System.Runtime.Serialization.StreamingContext context)
            { }
        }

        // saving the unit's info to a text file
        public override void save(string docPath)
        {
            string saveUnit = xPos + "," + yPos + "," + maxHealth + "," + speed + "," + attack + "," + attackRange + "," + team + "," + symbol + "," + health + "\n";
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "Ranged Units.txt")))
            {
                outputFile.WriteLine(saveUnit);
            }
        }
    }
}
