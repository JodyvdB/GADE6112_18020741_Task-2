﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    class ResourceBuilding : Building
    {

        // These variables are characteristics of the factory buildings
        private int resourcesGenerated, resourcesGenPerRound, resourcePoolRem, resourceType;

        // constructor
        public ResourceBuilding(int x, int y, int maxHP, int team, int symbol, int resourcePoolRem, int resourceType)
        {
            this.resourceType = resourceType;
            this.maxHP = maxHP;
            hp = maxHP;
            this.team = team;
            this.x = x;
            this.y = y;
            this.resourcePoolRem = resourcePoolRem;
            this.symbol = symbol;
        }

        // generates resources, removes from availabe resources.
        public void generateResource()
        {
            // the building can only be used if there is enough resources left and it is alive
            if (resourcePoolRem > 0 && hp > 0)
            {
                resourcesGenerated += resourcesGenPerRound;
                resourcePoolRem -= resourcesGenPerRound;
                symbol = resourcesGenerated;
            } 
        }

        // accessors and mutators for variables
        public override int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public int ResourceType
        {
            get
            {
                return resourceType;
            }
            set
            {
                resourceType = value;
            }
        }

        public int ResourcesGenerated
        {
            get
            {
                return resourcesGenerated;
            }
            set
            {
                resourcesGenerated = value;
            }
        }

        public int ResourcePoolRemaining
        {
            get
            {
                return resourcePoolRem;
            }
            set
            {
                resourcePoolRem = value;
            }
        }

        public int ResourcesGeneratedPerRound
        {
            get
            {
                return resourcesGenPerRound;
            }
            set
            {
                resourcesGenPerRound = value;
            }
        }

        public override int MaxHP
        {
            get
            {
                return maxHP;
            }
            set
            {
                maxHP = value;
            }
        }

        public override int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public override int HP
        {
            get
            {
                return hp;
            }
            set
            {
                hp = value;
            }
        }

        public override int Team
        {
            get
            {
                return team;
            }
            set
            {
                team = value;
            }
        }

        public override int Symbol
        {
            get
            {
                return symbol;
            }
            set
            {
                symbol = value;
            }
        }

        // This string will be displayed when you click on the buildings button
        public override string toString()
        {
            return "This resource building belongs to this team: " + this.team + ". It is positioned at: " + this.x + ", " + this.y + ".\nIts health: " + this.hp
                + "\nIt generates the " + resourceType + " resources, and has generated " + resourcesGenerated + " of that resource!" +
                " The building has " + resourcePoolRem + " resources remaining!";
        }

        // when building's health reaches 0
        public override void death()
        {
            throw new DeathException("Resource building has been destroyed!");
        }

        // Placing this system exception in the parent class also allows both child classes to access it.
        public class DeathException : System.Exception
        {
            // A new instance of the exception class named 'DeathException' is created.
            public DeathException() : base() { }

            // Creating a base for ths class with a message in a string format.
            public DeathException(string message) : base(message) { }

            // Using the 'inner' property, we can call the original exception that caused a problem.
            public DeathException(string message, System.Exception inner) : base(message, inner) { }

            // A constructor is required for a serialization for when an excpetion proagates from a remoting server to the client.
            // Serialization is essentially the storing of objects as bytes in memory.
            // 'streaming context' = source and destination.
            protected DeathException(System.Runtime.Serialization.SerializationInfo info,
                System.Runtime.Serialization.StreamingContext context)
            { }
        }

        // saving the building's info to text file
        public override void save(string docPath)
        {
            string saveBuilding = x + "," + y + "," + maxHP + "," + team + "," + symbol + "," + resourcePoolRem + "," + resourceType + "," + resourcesGenerated + "," + resourcesGenPerRound + "\n";
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "Resource Buildings.txt")))
            {
                outputFile.WriteLine(saveBuilding);
            }
        }
    }
}
