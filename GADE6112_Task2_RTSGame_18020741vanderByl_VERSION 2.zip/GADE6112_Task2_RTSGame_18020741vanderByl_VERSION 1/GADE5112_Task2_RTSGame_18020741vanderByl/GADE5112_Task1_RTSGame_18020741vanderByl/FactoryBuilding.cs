﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    class FactoryBuilding : Building
    {
        // Variables that are going to be needed in this class.
        public Map m = new Map();
        Unit[] addUnit;

        // These variables are characteristics of the factory buildings
        private string unitType;
        private int spawnX, spawnY, speed;

        // constructor
        public FactoryBuilding(int x, int y, int maxHP, int team, int symbol, int speed)
        {
            unitType = ("" + symbol);
            this.maxHP = maxHP;
            hp = maxHP;
            this.speed = speed;
            this.x = x;
            this.y = y;
            spawnX = x;
            this.team = team;

            // setting the spawn locations for the units below the building or above the building if the building is at lowest point.
            if (y >= 19)
            {
                spawnY = y - 1;
            } else
            {
                spawnY = y + 1;
            }
        }

        // This method handles the spawning of new units based on the speed of the factory.
        public void generateUnit()
        {
            // A new unit variable is needed to store the temp stats of the new unit to be added to the array later
            addUnit = new Unit[m.units.Length + 1];
            Unit unit = null;
            Random r = new Random();
            int tempAttack = 0;

            // creating the stats for the unit being generated.
            switch (r.Next(0, 4))
            {
                case 0: tempAttack = 40; break;
                case 1: tempAttack = 50; break;
                case 2: tempAttack = 60; break;
                case 3: tempAttack = 90; break;
            }

            // instantiating the temporary new unit
            if (unitType == "0" && team == 1) 
            {
                unit = new MeleeUnit(spawnX, spawnY, 100, 2, tempAttack, 30, team, ("" + symbol));

            } else if (unitType == "0" && team == 2) 
            {
                unit = new MeleeUnit(spawnX, spawnY, 100, 2, tempAttack, 30, team, ("" + symbol));
            }

            if (unitType == "1" && team == 1) 
            {
                unit = new RangedUnit(spawnX, spawnY, 100, 1, tempAttack, 90, team, ("" + symbol));

            } else if (unitType == "1" && team == 2) 
            {
                unit = new RangedUnit(spawnX, spawnY, 100, 1, tempAttack, 90, team, ("" + symbol));
            }

            // Adding the new unit to the array of units.
            for (int loop = 0; loop < addUnit.Length - 1; loop++)
            {
                addUnit[loop] = m.units[loop];
            }

            addUnit[addUnit.Length - 1] = unit;
            m.units = addUnit;
        }

        // accessors and mutators for variables
        public int Speed
        {
            get
            {
                return speed;
            }
            set
            {
                speed = value;
            }
        }

        public override int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public override int MaxHP
        {
            get
            {
                return maxHP;
            }
            set
            {
                maxHP = value;
            }
        }

        public override int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public override int HP
        {
            get
            {
                return hp;
            }
            set
            {
                hp = value;
            }
        }

        public override int Team
        {
            get
            {
                return team;
            }
            set
            {
                team = value;
            }
        }

        public override int Symbol
        {
            get
            {
                return symbol;
            }
            set
            {
                symbol = value;
            }
        }

        public string UnitType
        {
            get
            {
                return unitType;
            }
            set
            {
                unitType = value;
            }
        }

        public int SpawnX
        {
            get
            {
                return spawnX;
            }
            set
            {
                spawnX = value;
            }
        }

        public int SpawnY
        {
            get
            {
                return spawnY;
            }
            set
            {
                spawnY = value;
            }
        }

        // This string will be displayed when you click on the buildings button
        public override string toString()
        {
            return "This Factory belongs to this team: " + this.team + ". It is positioned at: " + this.x + ", " + this.y + ".\nIts health: " + this.hp + "\n" +
                "Creates " + this.unitType + " units every " + speed + " seconds at this location: " + this.spawnX + ", " + this.spawnY;
        }

        // When the building's health reaches 0
        public override void death()
        {
            throw new DeathException("Factory has been destroyed!");
        }

        // Placing this system exception in the parent class also allows both child classes to access it.
        public class DeathException : System.Exception
        {
            // A new instance of the exception class named 'DeathException' is created.
            public DeathException() : base() { }

            // Creating a base for ths class with a message in a string format.
            public DeathException(string message) : base(message) { }

            // Using the 'inner' property, we can call the original exception that caused a problem.
            public DeathException(string message, System.Exception inner) : base(message, inner) { }

            // A constructor is required for a serialization for when an excpetion proagates from a remoting server to the client.
            // Serialization is essentially the storing of objects as bytes in memory.
            // 'streaming context' = source and destination.
            protected DeathException(System.Runtime.Serialization.SerializationInfo info,
                System.Runtime.Serialization.StreamingContext context)
            { }
        }

        // saving the building's info to text file.
        public override void save(string docPath)
        {
            string saveBuilding = x + "," + y + "," + maxHP + "," + team + "," + symbol + "," + speed + "," + unitType + "," + spawnX + "," + spawnY + "\n";
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "Factory Buildings.txt")))
            {
                outputFile.WriteLine(saveBuilding);
            }
        }
    }
}
