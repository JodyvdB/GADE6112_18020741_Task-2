﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    public partial class frmRTSMain : Form
    {
        // Creating a GameEngine object.
        GameEngine engine;
        Map myMap = new Map(); 
        //FactoryBuilding fB;
        //ResourceBuilding rB;
        //RangedUnit rU;
        //MeleeUnit mU;
        int count = 0;

        public frmRTSMain()
        {
            InitializeComponent();
        }

        // When the form is loaded, the engine object is instantiated.
        private void frmRTSMain_Load(object sender, EventArgs e)
        {
            engine = new GameEngine(this, grpBxInfo);
        }

        // Whenever a tick happens in the timer, the timestamp is updated and the entire board of units is updated and moved.
        private void tmrGameTime_Tick(object sender, EventArgs e)
        {
            engine.updateMap();
            engine.updateDisplay();
            lblTimeStamp.Text = (++count).ToString();
        }

        // Method that adds a string to the listbox.
        public void displayInfo(string msg)
        {
            lstBxUnitInfo.Items.Add(msg);
        }

        // When the exit button is clicked, the form is closed and the program ends.
        private void btnExit_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = false;
            Environment.Exit(0);
        }

        // When the play button is clicked, the timer starts/continues and the simulation begins.
        private void btnPlay_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = true;
            engine.updateMap();
            engine.updateDisplay();
            lblTimeStamp.Text = (++count).ToString();
        }

        // When the pause button is clicked, the timer is disabled (keeping its value of time) until play is clicked again.
        private void btnPause_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = false;
        }

        // when this button is clicked, the specified location of text files will be located and the stats of each unit and building will be
        // saved in their respected text file
        private void btnSave_Click(object sender, EventArgs e)
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            foreach (Unit u in myMap.units)
            {
                if (u.GetType() == typeof(MeleeUnit))
                {
                    u.save(docPath);

                }
                else if (u.GetType() == typeof(RangedUnit))
                {
                    u.save(docPath);
                }
            }

            foreach (FactoryBuilding fB in myMap.fBuildings)
            {
                fB.save(docPath);
            }

            foreach (ResourceBuilding rB in myMap.rBuildings)
            {
                rB.save(docPath);
            }
        }

        // when this button is clicked, it will get the location of the text files and read all the text files from that folder and the load the units and buildings based
        // on their stats saved in the text files.
        private void btnLoad_Click(object sender, EventArgs e)
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            myMap.read(docPath);
        }
    }
}
